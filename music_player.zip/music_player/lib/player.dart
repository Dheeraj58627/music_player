import 'package:flutter/material.dart';
import 'package:music_player/home_page.dart';
import 'package:get/get.dart';

class player extends StatefulWidget {
  const player({super.key});

  @override
  State<player> createState() => _playerState();
}

class _playerState extends State<player> {
  double current_value = 0;
  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;
    return Scaffold(
      backgroundColor: Colors.deepPurple.withOpacity(0.6),
      appBar: AppBar(
        title: Text("Player"),
        centerTitle: true,
        backgroundColor: Colors.transparent,
        leading: InkWell(
            onTap: (){
              setState(() {
                Get.to(home_page());
              });
            },
            child: Icon(Icons.arrow_back_ios)),
        actions: [
          Icon(Icons.more_vert)
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: height*0.05,),
            Center(
              child: Container(
                height: height*0.35,
                width: width*0.7,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    image:NetworkImage("https://media.istockphoto.com/id/1136827057/vector/line-soundwave-abstract-background.jpg?s=612x612&w=0&k=20&c=i1fjGnRhQdqlhgGlKN1d0_fTKKjeo2tCMclXT0pCcIg="),
                    fit: BoxFit.cover,
                  ),
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(30),
                ),
              ),
            ),
            SizedBox(height: height*0.03,),
            Text("Deva deva",style: TextStyle(fontSize: 25),),

            SizedBox(height: height*0.05,),
            Slider(
                value: current_value,
                min:0.0,
                max:100,
                onChanged: (double value){
                  setState(() {
                    current_value = value;
                  });

                }
            ),
            Row(
              children: [
                Spacer(),
                Icon(Icons.arrow_back_ios,size: 50,),
                Icon(Icons.play_circle_filled,size: 75,),
                Icon(Icons.arrow_forward_ios,size: 50,),
                Spacer(),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
