import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:music_player/home_page.dart';
import 'package:music_player/signup.dart';
class login_page extends StatefulWidget {
  const login_page({super.key});

  @override
  State<login_page> createState() => _login_pageState();
}

class _login_pageState extends State<login_page> {
  TextEditingController email_controller = TextEditingController();
  TextEditingController password_controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final heigth = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding:  EdgeInsets.only(left: width*0.05,right: width*0.03),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  height: 200,
                  width: 200,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage("https://static.vecteezy.com/system/resources/thumbnails/010/063/543/small/music-festival-colorful-icon-with-notes-and-the-inscription-music-3d-render-png.png"),
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
              Center(child: Text("Login",style: TextStyle(fontSize: 40),)),
              SizedBox(height:heigth*0.02,),
              Text("Email",style: TextStyle(fontSize: 28),),
              SizedBox(height:heigth*0.02,),
              TextFormField(

                    controller: email_controller,
                decoration: InputDecoration(
                  hintText: "Enter your Email",
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                  )
                ),


              ),
              Text("Password",style: TextStyle(fontSize: 28),),
              SizedBox(height:heigth*0.02,),
              TextFormField(

                controller: password_controller,
                decoration: InputDecoration(
                    hintText: "Enter Password",
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    )
                ),


              ),
              SizedBox(height:heigth*0.02,),
              Center(
                child: InkWell(
                  onTap: (){
                    setState(() {
                      Get.to(signup_page());
                    });
                  },
                  child: InkWell(
                    onTap: (){
                      setState(() {
                        Get.to(home_page());
                      });
                    },
                    child: Container(
                      height: 50,
                      width: 100,
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Center(child: Text("Login",style: TextStyle(fontSize: 30),)),
                    ),
                  ),
                ),
              ),
              SizedBox(height:heigth*0.02,),
             Center(
               child: Container(
                 width: 240,
                 child: Row(
                   children: [
                     Text("Don't have an Account ? "),
                     InkWell(
                         onTap: (){
                           setState(() {
                             Get.to(signup_page());
                           });
                         },
                         child: Text("Sign Up",style: TextStyle(color: Colors.deepPurple),))
                   ],
                 ),
               ),
             ),
              
              
            ],
          ),
        ),
      ),
    );
  }
}
