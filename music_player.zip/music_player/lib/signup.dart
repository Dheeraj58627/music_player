import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:music_player/login.dart';

class signup_page extends StatefulWidget {
  const signup_page({super.key});

  @override
  State<signup_page> createState() => _signup_pageState();
}

class _signup_pageState extends State<signup_page> {
  TextEditingController email_controller = TextEditingController();
  TextEditingController password_controller = TextEditingController();
  TextEditingController name_controller = TextEditingController();
  TextEditingController mobile_controller = TextEditingController();
  @override
  Widget build(BuildContext context) {
    final heigth = MediaQuery.of(context).size.height;
    final width = MediaQuery.of(context).size.width;

    return Scaffold(
      body: SingleChildScrollView(
        child: Padding(
          padding:  EdgeInsets.only(left: width*0.05,right: width*0.03),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  height: 200,
                  width: 200,
                  decoration: BoxDecoration(
                    image: DecorationImage(
                      image: NetworkImage("https://static.vecteezy.com/system/resources/thumbnails/010/063/543/small/music-festival-colorful-icon-with-notes-and-the-inscription-music-3d-render-png.png"),
                    ),
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
              ),
              Center(child: Text("Registration",style: TextStyle(fontSize: 40),)),
              SizedBox(height:heigth*0.02,),
              Text("Full Name",style: TextStyle(fontSize: 28),),
              SizedBox(height:heigth*0.02,),
              TextFormField(
                controller: name_controller,
                decoration: InputDecoration(
                    hintText: "Enter Full Name",
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    )
                ),


              ),
              Text("Email Id",style: TextStyle(fontSize: 28),),
              SizedBox(height:heigth*0.02,),
              TextFormField(

                controller: email_controller,
                decoration: InputDecoration(
                    hintText: "Enter Email",
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    )
                ),


              ),
              SizedBox(height:heigth*0.02,),
              Text("Mobile No.",style: TextStyle(fontSize: 28),),
              SizedBox(height:heigth*0.02,),
              TextFormField(
                controller: mobile_controller,
                decoration: InputDecoration(
                    hintText: "Enter Mobile No.",
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    )
                ),


              ),
              Text("Password",style: TextStyle(fontSize: 28),),
              SizedBox(height:heigth*0.02,),
              TextFormField(

                controller: password_controller,
                decoration: InputDecoration(
                    hintText: "Enter Password",
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(30),
                    )
                ),


              ),
              SizedBox(height:heigth*0.02,),
              Center(
                child: InkWell(
                  onTap: (){
                    setState(() {
                      Get.to(login_page());
                    });
                  },
                  child: Container(
                    height: 50,
                    width: 150,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: Center(child: Text("Sign Up",style: TextStyle(fontSize: 30),)),
                  ),
                ),
              ),
              SizedBox(height:heigth*0.02,),
              Center(
                child: Container(
                  width: 240,
                  child: Row(
                    children: [
                      Text("Alredy have an account "),
                      InkWell(
                          onTap: (){
                            setState(() {
                              Get.to(login_page());
                            });
                          },
                          child: Text("Login",style: TextStyle(color: Colors.deepPurple),))
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
