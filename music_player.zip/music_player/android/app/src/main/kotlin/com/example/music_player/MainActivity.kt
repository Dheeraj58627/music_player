package com.example.music_player

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
