import 'package:flutter/material.dart';
import 'package:dio/dio.dart';
import 'package:flutter_api_project/auth_folder/model/register_model_file.dart';
import 'package:flutter_api_project/auth_folder/model/login_model_file.dart';
class Api_service{
  Dio dio = Dio();

  //register api
  Future<register> register_api(email,password,fname,lname) async{

    FormData user_form = FormData();
    user_form.fields.add(MapEntry("email",email));
    user_form.fields.add(MapEntry("password", password));
    user_form.fields.add(MapEntry("fname", fname));
    user_form.fields.add(MapEntry("lname", lname));


    final user_value = await dio.post("https://ashmairaconstructioninc.com/3dfitness/api/register",data: user_form);
    if(user_value.statusCode == 200){
        final result = register.fromJson(user_value.data);
        return result;

    }
    else{
      throw "server error";
    }
  }


  //login api
Future<login_model> login_api(email,password) async{

    FormData user_form = FormData();
    user_form.fields.add(MapEntry("email", email));
    user_form.fields.add(MapEntry("password", password));

    final user_value = await dio.post("https://www.sparkstoideas.com/3dfitness/api/login",data: user_form);
    if(user_value.statusCode == 200){
      final result = login_model.fromJson(user_value.data);
      return result;

    }
    else{
      throw "server error";
    }

}


}