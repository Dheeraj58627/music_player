class register {
  String? responseCode;
  String? message;
  String? status;
  UserData? userData;
  String? userToken;

  register(
      {this.responseCode,
        this.message,
        this.status,
        this.userData,
        this.userToken});

  register.fromJson(Map<String, dynamic> json) {
    responseCode = json['response_code'];
    message = json['message'];
    status = json['status'];
    userData = json['user_data'] != null
        ? new UserData.fromJson(json['user_data'])
        : null;
    userToken = json['user_token'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['response_code'] = this.responseCode;
    data['message'] = this.message;
    data['status'] = this.status;
    if (this.userData != null) {
      data['user_data'] = this.userData!.toJson();
    }
    data['user_token'] = this.userToken;
    return data;
  }
}

class UserData {
  String? id;
  String? fname;
  String? lname;
  String? email;
  String? password;
  String? date;
  String? time;
  String? profile;
  String? goal;
  String? location;
  String? difficulty;
  String? gender;
  String? birthday;
  String? height;
  String? weight;
  String? type;
  String? weightsStatus;
  String? distanceStatus;
  String? bodyweightsStatus;
  String? heightsStatus;
  String? fireKey;

  UserData(
      {this.id,
        this.fname,
        this.lname,
        this.email,
        this.password,
        this.date,
        this.time,
        this.profile,
        this.goal,
        this.location,
        this.difficulty,
        this.gender,
        this.birthday,
        this.height,
        this.weight,
        this.type,
        this.weightsStatus,
        this.distanceStatus,
        this.bodyweightsStatus,
        this.heightsStatus,
        this.fireKey});

  UserData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fname = json['fname'];
    lname = json['lname'];
    email = json['email'];
    password = json['password'];
    date = json['date'];
    time = json['time'];
    profile = json['profile'];
    goal = json['goal'];
    location = json['location'];
    difficulty = json['difficulty'];
    gender = json['gender'];
    birthday = json['birthday'];
    height = json['height'];
    weight = json['weight'];
    type = json['type'];
    weightsStatus = json['weights_status'];
    distanceStatus = json['distance_status'];
    bodyweightsStatus = json['bodyweights_status'];
    heightsStatus = json['heights_status'];
    fireKey = json['fire_key'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['fname'] = this.fname;
    data['lname'] = this.lname;
    data['email'] = this.email;
    data['password'] = this.password;
    data['date'] = this.date;
    data['time'] = this.time;
    data['profile'] = this.profile;
    data['goal'] = this.goal;
    data['location'] = this.location;
    data['difficulty'] = this.difficulty;
    data['gender'] = this.gender;
    data['birthday'] = this.birthday;
    data['height'] = this.height;
    data['weight'] = this.weight;
    data['type'] = this.type;
    data['weights_status'] = this.weightsStatus;
    data['distance_status'] = this.distanceStatus;
    data['bodyweights_status'] = this.bodyweightsStatus;
    data['heights_status'] = this.heightsStatus;
    data['fire_key'] = this.fireKey;
    return data;
  }
}
