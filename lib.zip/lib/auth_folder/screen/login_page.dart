import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_api_project/auth_folder/controller/login_controller_file.dart';
import 'package:flutter_api_project/auth_folder/screen/home_page.dart';
import 'package:flutter_api_project/auth_folder/screen/signup_page.dart';
import 'package:get/get.dart';

class login_page extends StatefulWidget {
  const login_page({super.key});

  @override
  State<login_page> createState() => _login_pageState();
}

class _login_pageState extends State<login_page> {
  final login_obj = Get.put(login_controller_class());

  TextEditingController email_controller = TextEditingController();
  TextEditingController password_controller = TextEditingController();

  bool obsecure=false;
  @override
  Widget build(BuildContext context) {
    final height= MediaQuery.of(context).size.height;
    final width= MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: Obx(
         () {
          return SingleChildScrollView(
            child: Center(
              child: Padding(
                padding:  EdgeInsets.only(left: width*0.050),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: height*0.080,),


                    // image container
                    Container(
                      height: height*0.3,
                      width: width*0.9,
                      decoration: BoxDecoration(
                        color: Colors.yellow,
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage("assests/image/dd.jpg")
                        )
                      ),
                    ),
                    SizedBox(height: height*0.050,),


                    Text("Login", style: TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w400),),
                    SizedBox(height: height*0.050,),

                    Text("Email", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w400),),
                    Container(
                      // padding: EdgeInsets.all(20),
                      alignment: Alignment.center,
                      height: height*0.080,
                      width: width*0.9,
                      child: TextFormField(
                        controller: email_controller,
                        autofocus: false,
                        decoration: InputDecoration(
                            hintText: "Enter name",
                            hintStyle: TextStyle(color: Colors.grey),
                            prefixIcon: Icon(Icons.email_outlined, color: Colors.black,),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(color: Colors.black)
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(color: Colors.black)
                            )
                        ),
                      ),
                    ),
                    SizedBox(height: height*0.010,),


                    Text("Password", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w400),),
                    Container(
                      //
                      alignment: Alignment.center,
                      height: height*0.080,
                      width: width*0.9,

                      child: TextFormField(
                        controller: password_controller,
                        autofocus: false,
                        obscureText: obsecure,
                        onTap: (){
                          setState(() {
                            obsecure=!obsecure;
                            print("obsecure value : $obsecure");
                          });
                        },
                        decoration: InputDecoration(
                            hintText: "Enter Password",
                            hintStyle: TextStyle(color: Colors.grey),
                            prefixIcon: Icon(Icons.lock_outline, color: Colors.black,),
                            suffixIcon: obsecure==false?Icon(Icons.remove_red_eye_outlined, color: Colors.black,) :Icon(Icons.remove_red_eye, color: Colors.black,),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(color: Colors.black)
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(20),
                                borderSide: BorderSide(color: Colors.black)
                            )
                        ),
                      ),
                    ),
                    SizedBox(height: height*0.050,),

                    // login buttom
                    Center(
                      child: InkWell(
                        onTap: (){
                          setState(() {
                            login_obj.login_cont_fun(
                              email_controller.text.toString(),
                              password_controller.text.toString(),
                            );
                          });
                        },
                        child: Container(
                          alignment: Alignment.center,
                          height: height*0.080,
                          width: width*0.4,
                          decoration:BoxDecoration(
                            borderRadius: BorderRadius.circular(20),
                            color: Colors.blue
                          ) ,
                          child: login_obj.loading.value?CupertinoActivityIndicator(color: Colors.black,):Text("Login", style: TextStyle(fontSize: 20),),
                        ),
                      ),
                    ),
                    SizedBox(height: height*0.030,),


                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("Don't have account ? ", style: TextStyle(fontSize: 20),),

                        InkWell(
                            onTap: (){
                              Get.to(signup_page());
                            },
                            child: Text("Signup", style: TextStyle(fontSize: 20, color: Colors.blue),)),

                      ],
                    )






                  ],
                ),
              ),
            ),
          );
        }
      ),
    );
  }
}
