import 'package:flutter/material.dart';
import 'package:flutter_api_project/auth_folder/screen/login_page.dart';
import 'package:get/get.dart';

import 'home_page.dart';

class signup_page extends StatefulWidget {
  const signup_page({super.key});

  @override
  State<signup_page> createState() => _signup_pageState();
}

class _signup_pageState extends State<signup_page> {
  TextEditingController name_controller = TextEditingController();
  TextEditingController surname_controller = TextEditingController();
  TextEditingController email_controller = TextEditingController();
  TextEditingController password_controller = TextEditingController();

  bool obsecure=false;
  @override
  Widget build(BuildContext context) {
    final height= MediaQuery.of(context).size.height;
    final width= MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding:  EdgeInsets.only(left: width*0.050),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: height*0.080,),


                // image container
                Container(
                  height: height*0.3,
                  width: width*0.9,
                  decoration: BoxDecoration(
                      color: Colors.yellow,
                      image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage("assests/image/download.jpg")
                      )
                  ),
                ),
                SizedBox(height: height*0.050,),


                Text("Signup", style: TextStyle(color: Colors.black, fontSize: 30, fontWeight: FontWeight.w400),),
                SizedBox(height: height*0.050,),

                Text("Name", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w400),),
                Container(
                  // padding: EdgeInsets.all(20),
                  alignment: Alignment.center,
                  height: height*0.080,
                  width: width*0.9,
                  child: TextFormField(
                    controller: name_controller,
                    autofocus: false,
                    decoration: InputDecoration(
                        hintText: "Enter name",
                        hintStyle: TextStyle(color: Colors.grey),
                        prefixIcon: Icon(Icons.email_outlined, color: Colors.black,),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        )
                    ),
                  ),
                ),
                SizedBox(height: height*0.010,),

                Text("Suarname", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w400),),
                Container(
                  // padding: EdgeInsets.all(20),
                  alignment: Alignment.center,
                  height: height*0.080,
                  width: width*0.9,
                  child: TextFormField(
                    controller: surname_controller,
                    autofocus: false,
                    decoration: InputDecoration(
                        hintText: "Enter surname",
                        hintStyle: TextStyle(color: Colors.grey),
                        prefixIcon: Icon(Icons.email_outlined, color: Colors.black,),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        )
                    ),
                  ),
                ),
                SizedBox(height: height*0.010,),


                Text("Email", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w400),),
                Container(
                  // padding: EdgeInsets.all(20),
                  alignment: Alignment.center,
                  height: height*0.080,
                  width: width*0.9,
                  child: TextFormField(
                    controller: email_controller,
                    autofocus: false,
                    decoration: InputDecoration(
                        hintText: "Enter email",
                        hintStyle: TextStyle(color: Colors.grey),
                        prefixIcon: Icon(Icons.email_outlined, color: Colors.black,),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        )
                    ),
                  ),
                ),
                SizedBox(height: height*0.010,),


                Text("Password", style: TextStyle(color: Colors.black, fontSize: 18, fontWeight: FontWeight.w400),),
                Container(
                  //
                  alignment: Alignment.center,
                  height: height*0.080,
                  width: width*0.9,

                  child: TextFormField(
                    controller: email_controller,
                    autofocus: false,
                    obscureText: obsecure,
                    onTap: (){
                      setState(() {
                        obsecure=!obsecure;
                        print("obsecure value : $obsecure");
                      });
                    },
                    decoration: InputDecoration(
                        hintText: "Enter Password",
                        hintStyle: TextStyle(color: Colors.grey),
                        prefixIcon: Icon(Icons.lock_outline, color: Colors.black,),
                        suffixIcon: obsecure==false?Icon(Icons.remove_red_eye, color: Colors.black,) :Icon(Icons.remove_red_eye_outlined, color: Colors.white,),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                            borderSide: BorderSide(color: Colors.black)
                        )
                    ),
                  ),
                ),
                SizedBox(height: height*0.050,),

                // login buttom


                Center(
                  child: InkWell(
                    onTap: (){
                      setState(() {
                        Get.to(home_page());
                      });
                    },
                    child: Container(
                      alignment: Alignment.center,
                      height: height*0.080,
                      width: width*0.4,
                      decoration:BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Colors.blue
                      ) ,
                      child: Text("Signup", style: TextStyle(fontSize: 20),),
                    ),
                  ),
                ),
                SizedBox(height: height*0.030,),


                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text("already have account ! ", style: TextStyle(fontSize: 20),),

                    InkWell(
                        onTap: (){
                          Get.to(login_page());
                        },
                        child: Text("Login", style: TextStyle(fontSize: 20, color: Colors.blue),)),

                  ],
                ),
                SizedBox(height: height*0.040,),







              ],
            ),
          ),
        ),
      ),
    );
  }
}
