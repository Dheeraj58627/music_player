import 'package:flutter/material.dart';

class home_page extends StatefulWidget {
  const home_page({super.key});

  @override
  State<home_page> createState() => _home_pageState();
}

class _home_pageState extends State<home_page> {
  @override
  Widget build(BuildContext context) {

    final height= MediaQuery.of(context).size.height;
    final width= MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.green,
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: height*0.050,),

            Container(
              height: height,
              color: Colors.transparent,
              width: width,
              child: GridView.count(
                crossAxisCount: 2,
                mainAxisSpacing: width*0.1,
                crossAxisSpacing: height*0.050,
                childAspectRatio: 1.5,
                children: List.generate(7, (index) {
                  return Container(
                    color: Colors.blue,
                    alignment: Alignment.center,
                    child: Text("$index"),
                  );
                }),


              ),
            )
          ],
        ),
      ),
    );
  }
}
