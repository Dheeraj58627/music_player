import 'package:flutter_api_project/api_service.dart';
import 'package:flutter_api_project/auth_folder/model/login_model_file.dart';
import 'package:flutter_api_project/auth_folder/screen/home_page.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

class login_controller_class extends GetxController{
  var loading  = false.obs;
  var old_response = login_model().obs;

  Future<void> login_cont_fun(email, password)async{
    try{
      loading(true);

      final new_responce = await Api_service().login_api(email, password);
      if(new_responce.responseCode=="1"){
        old_response = new_responce.obs;
        Get.to(home_page());

      }else{
        old_response = new_responce.obs;
        Fluttertoast.showToast(msg: "Login Failed....");

      }

    }
    finally{
      loading(false);
    }

  }
}