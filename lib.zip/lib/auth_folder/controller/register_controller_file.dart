import 'package:flutter_api_project/api_service.dart';
import 'package:flutter_api_project/auth_folder/model/register_model_file.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

class Register_controller_class extends GetxController{

  var loading = false.obs;
  var old_response = register().obs;

  Future<void> register_count_fun(email,password,fname,lname) async{
    try{
      loading(true);
      final new_response = await Api_service().register_api((email), password, fname, lname);

      if(new_response.responseCode == "1"){
        old_response = new_response.obs;
        Fluttertoast.showToast(msg:"successfully register...");
      }
      else{
        old_response = new_response.obs;
        Fluttertoast.showToast(msg:old_response.value.message.toString());

      }
    }
      finally{
        loading(false);
      }
  }
}